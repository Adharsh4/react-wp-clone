import React, {useState, useEffect} from 'react'
import { Avatar, IconButton } from '@material-ui/core'
import { SearchOutlined, AttachFile, MoreVert, InsertEmoticon } from '@material-ui/icons'
import MicIcon from '@material-ui/icons/Mic';
import SendIcon from '@material-ui/icons/Send';
import './Chat.css';
import axios from './axios';
import { useParams } from 'react-router';
import db from './firebase';
import { useStateValue } from './StateProvider';
import firebase from 'firebase';

function Chat({messages}) { //destructured the props to get specifically the messages alones

    const [input, setInput] = useState("");
    const {roomId} = useParams();
    const [roomName, setRoomName] = useState("");
    const [{ user }, dispatch] = useStateValue();
    const [messagesPerRoom, setMessagesPerRoom] = useState([]);

    useEffect(() => {
        if(roomId){
            db.collection('rooms').doc(roomId).onSnapshot(snapshot => {
                setRoomName(snapshot.data().name);
            })
        }
    }, [roomId])

    useEffect(() => {
        const mesgPerRoom = (messages.filter(message => message.roomId === roomId))
        setMessagesPerRoom(mesgPerRoom)
    }, [messages, roomId])

    const sendMessage = async (event) => {
        event.preventDefault();
        await axios.post("/messages/new", {
            message: input,
            name: user.displayName, // this displayName property will be from the one which google sent back
            timestamp: String(new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds() + " " + (new Date().getMonth()+1) +" " + new Date().getFullYear()),
            // timestamp: String(firebase.firestore.FieldValue.serverTimestamp()), // firebase serverTime
            received: false,
            roomId: roomId
        }).then(()=>{

        }).catch(()=>{
            console.log("error");
        });

        setInput('');
    }

    return (
        <div className = 'chat'>
            <div className = 'chat__header'>
                <Avatar />
                <div className = 'chat__headerInfo'>
                    <h3>{roomName}</h3>
                    <p>last seen now</p>
                </div>
                <div className = 'chat__headerRight'>
                    <IconButton>
                        <SearchOutlined />
                    </IconButton>
                    <IconButton>
                        <AttachFile />
                    </IconButton>
                    <IconButton>
                        <MoreVert />
                    </IconButton>
                </div>
            </div>

            <div className = 'chat__body'>

                {messagesPerRoom.map((message) => { // here in this also we can destructure like e did in props
                    return (<p key = {message._id} className = {`chat__message ${message.name === user.displayName && "chat__receiver"}`} >
                                <span className = 'chat__name'>{message.name}</span>
                                {message.message}
                                <span className = 'chat__timestamp'>
                                    {/* {new Date(message.timestamp?.toDate()).toUTCString()} */}
                                    {message.timestamp}
                                </span>
                            </p>
                        );
                })}
            </div>

            <div className = 'chat__footer'>
                <IconButton>
                    <InsertEmoticon />
                </IconButton>
                <form>
                    <input value = {input} onChange = {event => setInput(event.target.value)} type = 'text' placeholder = 'Type a message' />
                    <IconButton>
                        <SendIcon />
                    </IconButton>
                    <button onClick = {sendMessage} type = "submit" >Send message</button>
                </form>
                <MicIcon />
            </div>
            
        </div>
    )
}

export default Chat
