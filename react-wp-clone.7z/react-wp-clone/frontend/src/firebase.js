import firebase from 'firebase';

const firebaseConfig = {
    apiKey: "AIzaSyDPWy-cUx3NlM9uhvdix5PsdNFGerBh4uM",
    authDomain: "wp-mern.firebaseapp.com",
    databaseURL: "https://wp-mern.firebaseio.com",
    projectId: "wp-mern",
    storageBucket: "wp-mern.appspot.com",
    messagingSenderId: "117086964153",
    appId: "1:117086964153:web:265a14352a6ce709bdce68"
  };

  const firebaseApp = firebase.initializeApp(firebaseConfig);
  const db = firebaseApp.firestore();
  const auth = firebase.auth();
  const provider = new firebase.auth.GoogleAuthProvider();
  
  export {auth, provider};
  export default db; // default export coz we use db often 