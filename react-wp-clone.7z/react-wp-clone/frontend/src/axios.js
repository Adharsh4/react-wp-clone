import axios from 'axios';

const instance = axios.create({
    baseURL: "https://wp-be.herokuapp.com"
});

// https://wp-be.herokuapp.com
export default instance;