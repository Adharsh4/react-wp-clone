import React, {useEffect, useState} from 'react';
import './App.css';
import Sidebar from './Sidebar';
import Chat from './Chat';
import Pusher from 'pusher-js';
import axios from './axios';
import {BrowserRouter as Router, Switch, Route, withRouter} from 'react-router-dom';
import Login from './Login';
import { useStateValue } from './StateProvider';

function App() {

  const [messages, setMessages] = useState([]);
  // const [user, setUser] = useState(null);
  const [{user}, dispatch] = useStateValue();

  useEffect(() => {
    axios.get("/messages/sync")
      .then((response) => {
        setMessages(response.data);
    }).catch((err) => {

    })
  }, [])

  useEffect(() => {
    const pusher = new Pusher('3ebd7ef58b03232716c5', {
      cluster: 'ap2'
    });

    const channel = pusher.subscribe('messages');
    channel.bind('inserted', function(newMessage) {
      setMessages([...messages, newMessage]);
    });

    return () => { // this acts like a clean up funciton
      channel.unbind_all();
      channel.unsubscribe();
    }

  }, [messages]) //mentioning empty array will run this useEffect once at the load of component,
  //so in this case if we attach a listener we dont have to run the above code or function everytime
  // console.log(messages);
  return (
    <div className="app">
      {!user ? <Login /> : (
        <div className = 'app__body'>
        <Router>
        <Sidebar messages = {messages}/>
          <Switch>
            <Route path = "/rooms/:roomId">
              <Chat messages = {messages}/>
            </Route>
            <Route path = "/">
              {/* <Chat /> */}
            </Route>
          </Switch>
        </Router>
      </div>
      )}
      
    </div>
  );
}

export default App;
