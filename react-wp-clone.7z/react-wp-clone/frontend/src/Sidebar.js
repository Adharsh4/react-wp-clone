import React, { useState, useEffect } from 'react';
import './Sidebar.css';
import ChatIcon from '@material-ui/icons/Chat';
import DonutLargeIcon from '@material-ui/icons/DonutLarge';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import { Avatar, IconButton } from '@material-ui/core';
import { SearchOutlined } from '@material-ui/icons'
import SidebarChat from './SidebarChat';
import db from './firebase';
import { useStateValue } from './StateProvider';

function Sidebar(props) {

    const [rooms, setRooms] = useState([]);
    const[{user}, dispatch] = useStateValue();

    useEffect(() => {
        db.collection('rooms').onSnapshot(snapshot => {//'rooms' is the collection name that we added in firebase and we used firestone tab in firebase.com for database creation
        //onSnapshot - it acts like a function that will run whenever there is a change happening in the firebase database ...works as a realtime database....
        //example - acts like a camera that take a snapshot of the database in firebase and when any data 
        //added into that firebase db it takes a snapshot and since it is changed from the before snapshot it fires this function.... adds like a listener so eventhough 
        //useEffect euns only one time if anyy change in db it will fire tht function
            setRooms(snapshot.docs.map(doc => ( // here docs will have the list of documents we created inside the collection so since it is a list we can use map
                {
                    id: doc.id, // this id is the one that is auto generated in firebase
                    data: doc.data() // firebase will store like this ...like the values will be under data() so to fetch "name" from ot we need to use "data.name"
                }
            )))
        }) 

        // return () => { //cleanup function
        //     unsubscribe();
        // }
    }, []) // empty dependency means it will run one time

    return (
        <div className = 'sidebar'>
            <div className = 'sidebar__header'>
                <Avatar src = {user.photoURL}/> 
                {/* Avatar is also provided by material and it can take src which can have the person's image */}
                <div className = 'sidebar__headerRight'>
                    <IconButton> 
                        {/* Parent component provided by material UI to make the below button clickable */}
                        <DonutLargeIcon />
                    </IconButton>
                    <IconButton> 
                        <ChatIcon />
                    </IconButton>
                    <IconButton> 
                        <MoreVertIcon />
                    </IconButton>
                </div>
            </div>
            <div className='sidebar__search'>
                <div className = 'sidebar__searchContainer'>
                    <SearchOutlined />
                    <input placeholder = 'Search or start a new chat' type = "text"/>
                </div>

            </div>

            <div className = 'sidebar__chats'>
                <SidebarChat addNewChat/>
                {/* {console.log(rooms)} */}
                {rooms.map(room => {
                      return <SidebarChat key = {room.id} id = {room.id} name = {room.data.name} messages = {props.messages}/>
                })}
              
            </div>
        </div>
    )
}

export default Sidebar
