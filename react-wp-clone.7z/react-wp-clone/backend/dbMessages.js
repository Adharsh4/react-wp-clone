import mongoose from 'mongoose';

const whatsappSchema = mongoose.Schema({
    message: String,
    name: String,
    timestamp: String,
    received: Boolean,
    roomId: String
})

export default mongoose.model("messagecontents", whatsappSchema);// the string is the name of one of the collection
//gove the collection name as plural since mongoose adds 's' at end in database(if you check in mongodb.com)