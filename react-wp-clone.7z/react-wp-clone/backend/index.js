import express from 'express';
import mongoose from 'mongoose';//client for connecting to db
import Messages from './dbMessages.js'; // use with file extension
import Pusher from 'pusher';
import cors from 'cors';
// const express = require('express'); since we include type:module in package.json we dont use require.

const app = express(); //  app is in instance to use express and allow us to use routes. 

const port = process.env.PORT || 9000;

var pusher = new Pusher({
    appId: '1074739',
    key: '3ebd7ef58b03232716c5',
    secret: 'c0031987cacce3167703',
    cluster: 'ap2',
    encrypted: true
  });

app.use(express.json()) // witout using this middleware we dont get all the data in JSON form that we send from node 

app.use(cors()); // if we use cors we can get rid of the below lines coz cors will help us set some headers

// app.use((req, res, next) => {
//     res.setHeader("Access-Control-Allow-Origin", "*"); //allowing the request to come from any endpoints, everything will be accepted
//     res.setHeader("Access-Control-Allow-Headers", "*");
//     next(); // to go to the next middeware or run the functions below correspondingly
// })

const connnection_url = "mongodb+srv://admin:IK6aYzf9CoJJea4A@cluster0.vrgdj.mongodb.net/whatsappdb?retryWrites=true&w=majority";

mongoose.connect(connnection_url, {
    useCreateIndex: true,
    useNewUrlParser: true,
    useUnifiedTopology: true
})

const db = mongoose.connection;

db.once('open', () => {   //once mongoose connection is open, we fire a function
    // console.log("db is connected");
    const mesgCollection = db.collection("messagecontents");
    const changeStream = mesgCollection.watch(); // this changeStream is watching the collection named "messagecontents" for nay changes

    changeStream.on('change', (change) => { // since changeStream is watching if there is any change in db (on('change')) we fire an function
        console.log(change);

        if(change.operationType === 'insert'){ // these operationTypr and fullDocument will be available under change...console log "change" that you got from the callback function parameter and you wil find those
            const mesgDetails = change.fullDocument;
            pusher.trigger('messages', 'inserted', {  // here if we go to debug console inside pusher.com you can see the channel name as messages and events as inserted(to reflect in debug console ...that debug console window has to be opened and then make a post request through postman)
                name: mesgDetails.name,
                message: mesgDetails.message,
                timestamp: mesgDetails.timestamp,
                received: mesgDetails.received,
                roomId: mesgDetails.roomId
            })
        }
    })
}) 

app.get("/", (req, res) => res.status(200).send("Hello world"));

app.post("/messages/new", (req, res) => {
    const dbmessage = req.body;
    Messages.create(dbmessage, (err, data) => {
        if(err){
            res.status(500).send(err); // 500 - internal server error
        }else{
            res.status(201).send(data); // 201 - created OK
        }
    })
})

app.get("/messages/sync", (req, res) => {
    Messages.find((err, data) => {
        if(err){
            res.status(500).send(err);
        }else{
            res.status(200).send(data);
        }
    })
})

app.listen(port, () => console.log(`listening to port ${port}`));